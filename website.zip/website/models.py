# myapp/models.py
import random

from django.db import models
from django.contrib.auth.models import User


class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    # Add additional fields as needed


class UserInput(models.Model):
    text_input = models.CharField(max_length=255)


class Leaderboard(models.Model):
    team_name = models.CharField(max_length=100)
    # score = models.PositiveIntegerField()
    score = random.randint(50, 100)

class LoginEvent(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    timestamp = models.DateTimeField()

class UserSession(models.Model):
    user = models.CharField(max_length=255)
    session_length = models.IntegerField()  # You can adjust the field type as needed
    timestamp = models.DateTimeField()

class SessionData(models.Model):
    user = models.CharField(max_length=255)
    correct_answers = models.PositiveIntegerField()
    wrong_answers = models.PositiveIntegerField()
    toggled_frequency = models.PositiveIntegerField()
    question_id = models.JSONField()
    question_status = models.JSONField()
    reaction_timestamp = models.JSONField()
    timestamp = models.DateTimeField()
    model_data = models.JSONField()


