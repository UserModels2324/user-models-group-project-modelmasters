import random

from example.info import Info


def create_leaderboard():
    group_names = ["Blue Guppies", "Red Pandas (Your Team)", "Green Gnomes", "Yellow Parakeets"]
    leaderboard = [(name, random.randint(50, 70)) for name in group_names]
    leaderboard.sort(key=lambda x: x[1], reverse=True)
    Info.leaderboard = leaderboard


def get_leaderboard():
    return Info.leaderboard


def update_leaderboard(correct_answer):
    # Red Pandas is participant team
    # update scores based on whether answer from participant was correct
    new_leaderboard = []
    for group in Info.leaderboard:
        # if participant group, increase/decrease based on participant scores
        if group[0] == "Red Pandas (Your Team)":
            change = [-3, 0]
            if correct_answer: change = [0, 3]
            score = group[1] + random.randrange(change[0], change[1])
            if score < 5: score = 5
            new_leaderboard.append((group[0], score))
            continue

        # else increase/ decrease randomly
        change = [-3, 3]
        if correct_answer: change = [-3, 2]
        score = group[1] + random.randrange(change[0], change[1])
        if score < 5: score = 5
        new_leaderboard.append((group[0], score))

    new_leaderboard.sort(key=lambda x: x[1], reverse=True)
    Info.leaderboard = new_leaderboard
