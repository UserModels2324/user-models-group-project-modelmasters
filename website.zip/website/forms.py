# myapp/forms.py
from django import forms


class UserInputForm(forms.Form):
    text_input = forms.CharField(max_length=255)


class InputForm(forms.Form):
    first_name = forms.CharField(max_length=200)
    last_name = forms.CharField(max_length=200)
    roll_number = forms.IntegerField(
        help_text="Enter 6 digit roll number"
    )
    password = forms.CharField(widget=forms.PasswordInput())


class AnswerForm(forms.Form):
    answer = forms.IntegerField(
        help_text="Enter answer"
    )


class SliderForm(forms.Form):
    # Define a field for the slider
    slider_value = forms.IntegerField(
        widget=forms.TextInput(attrs={'type': 'range', 'min': '1', 'max': '10', 'step': '1'}),
        label='Select a value between 1 and 10 minutes',
    )