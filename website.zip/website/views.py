# example/views.py
import random
import time

from django.shortcuts import render

from .forms import UserInputForm, InputForm, SliderForm
from .leaderboard import get_leaderboard, create_leaderboard, update_leaderboard
from .slimstampen.spacingmodel import SpacingModel, Response
from .slimstampen_utility_functions import add_facts
from .info import Info

from django.contrib.auth.models import User
from django.utils import timezone


from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import random
import time
from datetime import datetime

from django.http import HttpResponse

from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login

from .forms import UserInputForm, InputForm
from .slimstampen.spacingmodel import SpacingModel, Response
from .slimstampen_utility_functions import add_facts
from .info import Info

from .models import Leaderboard, LoginEvent, UserSession, SessionData
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

def index(request, username):
    context = {
        'participant_name': username,
    }
    return render(request, 'home.html', context)

def choose_session(request, participant_name):
    # choose session length
    session_length = 2  # Time in minutes
    if request.method == 'POST':
        form = SliderForm(request.POST)
        if form.is_valid():
            session_length = form.cleaned_data['slider_value']
            UserSession.objects.create(
                user=participant_name,  # Assuming the user is authenticated
                session_length=session_length,
                timestamp = timezone.now()
                # Add more fields for other session-related information
            )
    else:
        form = SliderForm()

    Info.session_length = session_length
    Info.session_start_time = False

    # start the session
    model = SpacingModel()
    add_facts(model, "33-chinese-words.csv")

    Info.model = model
    Info.correct_answer = 0
    Info.wrong_answer = 0
    Info.toggled = 0
    Info.question = 0
    Info.question_id = []
    Info.question_status = []
    Info.reaction_timestamp = []
    create_leaderboard()
    return render(request, 'session/choose_session.html', {"slider": form, "time": session_length, "participant_name" : participant_name})


def session_view(request, participant_name):
    """ Sorry that this function is a bit of a mess :O """
    
    # Calculate when start/end session
    if not Info.session_start_time:
        Info.session_start_time = int(time.monotonic()) % 1000 * 1000
        Info.session_end_time = Info.session_start_time + (Info.session_length * 60 * 1000)


    model = Info.model
    # SAVE PREVIOUS RESPONSE
    if Info.end_time and Info.end_time > Info.start_time:
        rt = int(Info.end_time - Info.start_time)
        response = Response(fact=Info.curr_fact[0], start_time=Info.start_time, rt=rt, correct=Info.correct)
        model.register_response(response)
        # model.get_rate_of_forgetting()

    # CHECK ANSWER
    if request.method == 'POST':
        Info.question+=1
        Info.question_id.append(Info.question)
        curr_time = int(time.monotonic()) % 1000 * 1000
        Info.end_time = curr_time
        fact = Info.curr_fact

        form = UserInputForm(request.POST)
        if form.is_valid():
            # Check that answer is correct
            user_input = form.cleaned_data['text_input']
            correct = False
            timestamp = timezone.now()
            timestamp_str = timestamp.strftime("%Y-%m-%d %H:%M:%S")
            Info.reaction_timestamp.append(timestamp_str)
            if user_input.lower() == fact[0].answer:
                correct = True
                Info.correct_answer += 1
                Info.question_status.append('T')
            else:
                Info.wrong_answer += 1
                Info.question_status.append('F')

            answer = f"That is wrong :(\nThe correct answer is {fact[0].answer}."
            if correct:
                answer = "That is correct!"

            Info.correct = correct
            update_leaderboard(correct)
            # model.register
            return render(request, 'session/result.html', {'form': form, 'answer': answer, 'participant_name':participant_name,
                                                           'leaderboard': get_leaderboard()})
    # SESSION TIME OVER
    if Info.session_end_time <= int(time.monotonic()) % 1000 * 1000:
        # TODO: This is where the session ends :)
        user = participant_name
        correct_answers = Info.correct_answer
        wrong_answers = Info.wrong_answer
        toggled_frequency = Info.toggled
        question_id = Info.question_id
        question_status = Info.question_status
        reaction_timestamp = Info.reaction_timestamp
        df = model.export_data()
        model_data = df.to_json(orient='records')
        session_data = SessionData(user=user, correct_answers=correct_answers, wrong_answers=wrong_answers, toggled_frequency=toggled_frequency, question_id=question_id, question_status=question_status, reaction_timestamp=reaction_timestamp,  timestamp = timezone.now(), model_data=model_data)
        session_data.save()

        return render(request, 'session/session_end.html', {'correct': Info.correct_answer, 'wrong': Info.wrong_answer, 'participant_name':participant_name,
                                                            'leaderboard': get_leaderboard()})

    # QUESTION
    curr_time = int(time.monotonic()) % 1000 * 1000
    start_time = curr_time
    Info.start_time = start_time
    fact = model.get_next_fact(current_time=int(start_time))
    Info.curr_fact = fact
    question = fact[0].question

    form = UserInputForm()
    # NEW FACT to learn
    if fact[1]:
        return render(request, 'session/learn_fact.html', {'form': form, 'question': question, 'answer': fact[0].answer,
                                                           'leaderboard': get_leaderboard()})

    return render(request, 'session/session_leaderboard.html', {'form': form, 'question': question,
                                                                'leaderboard': get_leaderboard()})

def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            # login(request, user)
            login_time = timezone.now()
            LoginEvent.objects.create(user=user, timestamp=login_time)
            return redirect('index', username=username)  # Pass username as a parameter
        else:
            error_message = "Invalid username or password. Please try again."
            return render(request, 'login.html', {'error_message': error_message})
    return render(request, 'login.html')


def input_form(request):
    if request.method == 'POST':
        form = UserInputForm(request.POST)
        if form.is_valid():
            user_input = form.cleaned_data['text_input']
            print(user_input)
            # TODO: If you want to save the input to the database (optional)
            # user = UserInput(text_input=user_input)
            # user.save()
            return render(request, 'result.html', {'user_input': user_input})
    else:
        form = UserInputForm()
    return render(request, 'input_form.html', {'form': form})


def leaderboard_view(request):
    group_names = ["Blue Guppies", "Red Pandas", "Green Gnomes", "Yellow Parakeets"]
    leaderboard = [(name, random.randint(50, 100)) for name in group_names]
    leaderboard.sort(key=lambda x: x[1], reverse=True)
    return render(request, 'leaderboard.html', {'leaderboard': leaderboard})

@csrf_exempt
def toggle_leaderboard(request):
    if request.method == 'POST':
        visible = request.POST.get('visible')  # Get the visibility state from the request
        # Process the visibility information as needed (e.g., store it in the database)
        # You can add your custom logic here
        response_data = {'message': 'Toggle event received.'}
        # print("VISIBILITY:", visible)
        Info.toggled += 1
        return JsonResponse(response_data)
    return JsonResponse({'message': 'Invalid request.'})
